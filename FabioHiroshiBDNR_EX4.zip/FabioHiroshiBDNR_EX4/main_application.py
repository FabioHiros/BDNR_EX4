
import traceback
from db_connection import connect_to_astradb, initialize_keyspace_and_tables, verify_database_structure
from user_operations import inserir_usuario, atualizar_usuario
from product_operations import inserir_produto, buscar_produto
from order_operations import inserir_compra, deletar_compra
from data_operations import listar_todos_dados

def menu_principal():
    """Main menu for the application"""
    while True:
        print("\n" + "="*40)
        print("  MERCADO LIVRE - ASTRA DB")
        print("="*40)
        print("1. Inserir dados")
        print("2. Atualizar Usuário")
        print("3. Buscar Produto")
        print("4. Deletar Compra")
        print("5. Listar todos os dados")
        print("6. Verificar estrutura do banco")
        print("7. Sair")
        print("="*40)
        
        opcao = input("Escolha uma opção: ")
        
        if opcao == '1':
            menu_inserir()
        elif opcao == '2':
            atualizar_usuario(session)
        elif opcao == '3':
            buscar_produto(session)
        elif opcao == '4':
            deletar_compra(session)
        elif opcao == '5':
            listar_todos_dados(session)
        elif opcao == '6':
            verify_database_structure(session)
        elif opcao == '7':
            print("Encerrando programa...")
            break
        else:
            print("Opção inválida!")

def menu_inserir():
    """Insert menu for different data types"""
    while True:
        print("\n--- MENU INSERIR ---")
        print("1. Inserir Usuário/Vendedor")
        print("2. Inserir Produto")
        print("3. Inserir Compra")
        print("4. Voltar ao menu principal")
        
        opcao = input("Escolha uma opção: ")
        
        if opcao == '1':
            inserir_usuario(session)
        elif opcao == '2':
            inserir_produto(session)
        elif opcao == '3':
            inserir_compra(session)
        elif opcao == '4':
            break
        else:
            print("Opção inválida!")


session = None
cluster = None

if __name__ == "__main__":
    try:
        print("Conectando ao AstraDB...")
        
        cluster, session = connect_to_astradb()
        print("✓ Conectado com sucesso!")
        

        initialize_keyspace_and_tables(session)
        print("✓ Base de dados configurada!")
        

        menu_principal()
        
    except Exception as e:
        print(f"❌ Erro de conexão: {e}")
        print("\nVerifique se:")
        print("1. O arquivo 'secure-connect-mercado-livre.zip' está na pasta")
        print("2. O token está correto")
        print("3. Você tem conexão com a internet")
        traceback.print_exc()
    finally:
        if cluster:
            cluster.shutdown()
            print("Conexão encerrada.")
