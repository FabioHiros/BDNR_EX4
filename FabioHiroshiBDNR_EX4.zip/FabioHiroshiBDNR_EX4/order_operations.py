
import uuid
import traceback
from datetime import datetime

def inserir_compra(session):
    """Insert a new purchase with product selection"""
    print("\n--- INSERIR COMPRA ---")
    try:
        cpf_comprador = input("CPF do comprador: ")
        
        # Buscar comprador
        find_user = session.prepare("SELECT id, nome FROM usuarios WHERE cpf = ? ALLOW FILTERING")
        user_rows = session.execute(find_user, [cpf_comprador])
        user = list(user_rows)
        
        if not user:
            print("Comprador não encontrado!")
            return
        
        comprador_id = user[0].id
        print(f"Comprador: {user[0].nome}")
        
        # Listar produtos disponíveis
        print("\n--- PRODUTOS DISPONÍVEIS ---")
        # Get all products and filter in Python (avoid ALLOW FILTERING)
        all_products = session.execute("SELECT * FROM produtos")
        product_list = [p for p in all_products if p.estoque > 0]
        
        if not product_list:
            print("Não há produtos disponíveis no momento!")
            return
        
        print("-" * 80)
        print(f"{'#':<3} {'Nome':<25} {'Marca':<15} {'Preço':<10} {'Estoque':<8}")
        print("-" * 80)
        
        for i, product in enumerate(product_list, 1):
            # Buscar nome do vendedor
            find_vendor = session.prepare("SELECT nome FROM usuarios WHERE id = ?")
            vendor_rows = session.execute(find_vendor, [product.vendedor_id])
            vendor = list(vendor_rows)
            vendor_name = vendor[0].nome if vendor else "Desconhecido"
            
            print(f"{i:<3} {product.nome[:25]:<25} {product.marca[:15]:<15} R$ {float(product.valor):<7.2f} {product.estoque:<8}")
            print(f"    Descrição: {product.descricao}")
            print(f"    Vendedor: {vendor_name}")
            print("-" * 80)
        
        # Selecionar produtos para a compra
        selected_products = []
        total_value = 0.0
        
        print("\n--- SELEÇÃO DE PRODUTOS ---")
        print("Digite o número do produto que deseja adicionar (0 para finalizar):")
        
        while True:
            try:
                choice = int(input("\nNúmero do produto: "))
                
                if choice == 0:
                    if selected_products:
                        break
                    else:
                        print("Você precisa selecionar pelo menos um produto!")
                        continue
                
                if 1 <= choice <= len(product_list):
                    selected_product = product_list[choice - 1]
                    
                    # Verificar se já foi selecionado
                    already_selected = False
                    for item in selected_products:
                        if item['product_id'] == selected_product.id:
                            print("Este produto já foi selecionado!")
                            already_selected = True
                            break
                    
                    if already_selected:
                        continue
                    
                    print(f"\nProduto selecionado: {selected_product.nome}")
                    print(f"Preço unitário: R$ {float(selected_product.valor):.2f}")
                    print(f"Estoque disponível: {selected_product.estoque}")
                    
                    max_qty = selected_product.estoque
                    quantity = int(input(f"Quantidade desejada (máx {max_qty}): "))
                    
                    if quantity <= 0:
                        print("Quantidade deve ser maior que zero!")
                        continue
                    
                    if quantity > max_qty:
                        print(f"Quantidade não disponível! Máximo: {max_qty}")
                        continue
                    
                    # Adicionar à lista de produtos selecionados
                    # Convert Decimal to float for calculations
                    product_value = float(selected_product.valor)
                    product_total = product_value * quantity
                    selected_products.append({
                        'product_id': selected_product.id,
                        'nome': selected_product.nome,
                        'valor': product_value,
                        'quantidade': quantity,
                        'subtotal': product_total,
                        'vendedor_id': selected_product.vendedor_id
                    })
                    
                    total_value += product_total
                    
                    print(f"✓ Adicionado: {quantity}x {selected_product.nome}")
                    print(f"Subtotal: R$ {product_total:.2f}")
                    print(f"Total atual da compra: R$ {total_value:.2f}")
                    
                else:
                    print("Número inválido! Tente novamente.")
                    
            except ValueError:
                print("Digite um número válido!")
        
        # Exibir resumo da compra
        print("\n" + "="*50)
        print("RESUMO DA COMPRA")
        print("="*50)
        print(f"Comprador: {user[0].nome}")
        print("Produtos selecionados:")
        print("-" * 50)
        
        for item in selected_products:
            print(f"{item['quantidade']}x {item['nome']}")
            print(f"  R$ {item['valor']:.2f} cada = R$ {item['subtotal']:.2f}")
            print()
        
        print("-" * 50)
        print(f"TOTAL: R$ {total_value:.2f}")
        print("="*50)
        
        # Confirmar compra
        confirm = input("\nConfirmar compra? (s/n): ")
        if confirm.lower() != 's':
            print("Compra cancelada!")
            return
        
        # Criar a compra
        order_id = uuid.uuid4()
        
        # Inserir compra principal
        insert_order = session.prepare("""
            INSERT INTO compras (id, comprador_id, status, valor_total, data_criacao)
            VALUES (?, ?, ?, ?, ?)
        """)
        session.execute(insert_order, [order_id, comprador_id, "Pedido Realizado", total_value, datetime.now()])
        
        # Atualizar estoque dos produtos
        for item in selected_products:
            # Get current stock first
            get_stock = session.prepare("SELECT estoque FROM produtos WHERE id = ?")
            current_stock_result = session.execute(get_stock, [item['product_id']])
            current_stock_row = list(current_stock_result)
            
            if current_stock_row:
                current_stock = current_stock_row[0].estoque
                new_stock = current_stock - item['quantidade']
                
                # Update with the new calculated value
                update_stock = session.prepare("UPDATE produtos SET estoque = ? WHERE id = ?")
                session.execute(update_stock, [new_stock, item['product_id']])
        
        print(f"\n✓ Compra realizada com sucesso!")
        print(f"✓ ID da compra: {order_id}")
        print(f"✓ Estoque dos produtos atualizado")
        print(f"✓ Total: R$ {total_value:.2f}")
        
    except Exception as e:
        print(f"❌ Erro ao inserir compra: {e}")
        traceback.print_exc()

def deletar_compra(session):
    """Delete a purchase"""
    print("\n--- DELETAR COMPRA ---")
    try:
        # Listar todas as compras
        rows = session.execute("SELECT * FROM compras")
        compras = list(rows)
        
        if not compras:
            print("Nenhuma compra encontrada!")
            return
        
        print("\nCompras disponíveis:")
        print("-" * 60)
        for i, compra in enumerate(compras, 1):
            # Buscar nome do comprador
            find_buyer = session.prepare("SELECT nome FROM usuarios WHERE id = ?")
            buyer_rows = session.execute(find_buyer, [compra.comprador_id])
            buyer = list(buyer_rows)
            buyer_nome = buyer[0].nome if buyer else "Desconhecido"
            
            print(f"{i}. ID: {compra.id}")
            print(f"   Comprador: {buyer_nome}")
            print(f"   Status: {compra.status}")
            print(f"   Valor: R$ {float(compra.valor_total):.2f}")
            print(f"   Data: {compra.data_criacao}")
            print()
        
        escolha = int(input("Digite o número da compra a deletar: ")) - 1
        if 0 <= escolha < len(compras):
            compra_id = compras[escolha].id
            delete_order = session.prepare("DELETE FROM compras WHERE id = ?")
            session.execute(delete_order, [compra_id])
            print(f"✓ Compra {compra_id} deletada com sucesso!")
        else:
            print("Número inválido!")
            
    except ValueError:
        print("Entrada inválida!")
    except Exception as e:
        print(f"❌ Erro ao deletar compra: {e}")
        traceback.print_exc()
