
import uuid
import traceback

def inserir_usuario(session):
    """Insert a new user (and seller if applicable)"""
    print("\n--- INSERIR USUÁRIO ---")
    try:
        # Verificar se a tabela existe antes de tentar inserir
        table_check = session.execute(f"""
            SELECT table_name FROM system_schema.tables 
            WHERE keyspace_name = '{session.keyspace}' AND table_name = 'usuarios'
        """)
        if not list(table_check):
            print("❌ Tabela 'usuarios' não existe!")
            return
            
        nome = input("Nome: ")
        sobrenome = input("Sobrenome: ")
        email = input("Email: ")
        cpf = input("CPF: ")
        senha = input("Senha: ")
        is_seller = input("É vendedor? (s/n): ").lower() == 's'
        
        # Gerar ID único
        user_id = uuid.uuid4()
        
        # Inserir usuário na tabela usuarios (sem dados de vendedor)
        insert_user = session.prepare("""
            INSERT INTO usuarios (id, nome, sobrenome, email, cpf, senha, is_seller)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """)
        
        # Executar inserção do usuário
        session.execute(insert_user, [user_id, nome, sobrenome, email, cpf, senha, is_seller])
        print(f"✓ Usuário inserido com ID: {user_id}")
        
        # Se é vendedor, inserir na tabela vendedores separada
        if is_seller:
            print("\n--- DADOS DE VENDEDOR ---")
            company_name = input("Nome da empresa: ")
            cnpj = input("CNPJ: ")
            rating = 0.0  # Rating inicial
            
            # Inserir na tabela vendedores
            vendor_id = uuid.uuid4()
            insert_vendor = session.prepare("""
                INSERT INTO vendedores (id, user_id, company_name, cnpj, rating)
                VALUES (?, ?, ?, ?, ?)
            """)
            session.execute(insert_vendor, [vendor_id, user_id, company_name, cnpj, rating])
            print(f"✓ Dados de vendedor inseridos com ID: {vendor_id}")
            
    except Exception as e:
        print(f"❌ Erro ao inserir usuário: {e}")
        traceback.print_exc()

def atualizar_usuario(session):
    """Update user information"""
    print("\n--- ATUALIZAR USUÁRIO ---")
    try:
        cpf = input("Digite o CPF do usuário a atualizar: ")
        
        # Buscar usuário
        find_user = session.prepare("SELECT * FROM usuarios WHERE cpf = ? ALLOW FILTERING")
        user_rows = session.execute(find_user, [cpf])
        user = list(user_rows)
        
        if not user:
            print("Usuário não encontrado!")
            return
        
        user_data = user[0]
        print(f"\nDados atuais:")
        print(f"Nome: {user_data.nome} {user_data.sobrenome}")
        print(f"Email: {user_data.email}")
        print(f"É vendedor: {'Sim' if user_data.is_seller else 'Não'}")
        
        # Se é vendedor, mostrar dados da tabela vendedores
        if user_data.is_seller:
            find_vendor = session.prepare("SELECT * FROM vendedores WHERE user_id = ? ALLOW FILTERING")
            vendor_rows = session.execute(find_vendor, [user_data.id])
            vendor = list(vendor_rows)
            if vendor:
                vendor_data = vendor[0]
                print(f"Empresa: {vendor_data.company_name}")
                print(f"CNPJ: {vendor_data.cnpj}")
                print(f"Rating: {vendor_data.rating}")
        
        print("\nDeixe em branco para manter o valor atual:")
        novo_nome = input("Novo nome: ")
        novo_sobrenome = input("Novo sobrenome: ")
        novo_email = input("Novo email: ")
        
        # Atualizar apenas campos que foram preenchidos
        if novo_nome:
            update_name = session.prepare("UPDATE usuarios SET nome = ? WHERE id = ?")
            session.execute(update_name, [novo_nome, user_data.id])
        if novo_sobrenome:
            update_lastname = session.prepare("UPDATE usuarios SET sobrenome = ? WHERE id = ?")
            session.execute(update_lastname, [novo_sobrenome, user_data.id])
        if novo_email:
            update_email = session.prepare("UPDATE usuarios SET email = ? WHERE id = ?")
            session.execute(update_email, [novo_email, user_data.id])
        
        print("✓ Usuário atualizado com sucesso!")
        
    except Exception as e:
        print(f"❌ Erro ao atualizar usuário: {e}")
        traceback.print_exc()
