
import traceback

def listar_todos_dados(session):
    """List all data in the database"""
    print("\n--- TODOS OS DADOS ---")
    try:
        # Listar usuários
        print("\n1. USUÁRIOS:")
        print("-" * 80)
        users = session.execute("SELECT * FROM usuarios")
        for user in users:
            tipo = "Vendedor" if user.is_seller else "Comprador"
            print(f"Nome: {user.nome} {user.sobrenome} ({tipo})")
            print(f"CPF: {user.cpf}, Email: {user.email}")
            
            # Se é vendedor, buscar informações na tabela vendedores
            if user.is_seller:
                find_vendor = session.prepare("SELECT * FROM vendedores WHERE user_id = ? ALLOW FILTERING")
                vendor_rows = session.execute(find_vendor, [user.id])
                vendor = list(vendor_rows)
                if vendor:
                    vendor_data = vendor[0]
                    print(f"Empresa: {vendor_data.company_name} (CNPJ: {vendor_data.cnpj})")
                    print(f"Rating: {vendor_data.rating}")
            print("-" * 80)
        
        # Listar produtos
        print("\n2. PRODUTOS:")
        print("-" * 80)
        products = session.execute("SELECT * FROM produtos")
        for product in products:
            # Buscar vendedor
            find_vendor = session.prepare("SELECT nome FROM usuarios WHERE id = ?")
            vendor_rows = session.execute(find_vendor, [product.vendedor_id])
            vendor = list(vendor_rows)
            vendor_name = vendor[0].nome if vendor else "Desconhecido"
            
            print(f"Produto: {product.nome} ({product.marca})")
            print(f"Preço: R$ {float(product.valor):.2f}, Estoque: {product.estoque}")
            print(f"Vendedor: {vendor_name}")
            print("-" * 80)
        
        # Listar compras
        print("\n3. COMPRAS:")
        print("-" * 80)
        orders = session.execute("SELECT * FROM compras")
        for order in orders:
            # Buscar comprador
            find_buyer = session.prepare("SELECT nome FROM usuarios WHERE id = ?")
            buyer_rows = session.execute(find_buyer, [order.comprador_id])
            buyer = list(buyer_rows)
            buyer_name = buyer[0].nome if buyer else "Desconhecido"
            
            print(f"Compra ID: {order.id}")
            print(f"Comprador: {buyer_name}")
            print(f"Status: {order.status}, Valor: R$ {float(order.valor_total):.2f}")
            print(f"Data: {order.data_criacao}")
            print("-" * 80)
            
    except Exception as e:
        print(f"❌ Erro ao listar dados: {e}")
        traceback.print_exc()
