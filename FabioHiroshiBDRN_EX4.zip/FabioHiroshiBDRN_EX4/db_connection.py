
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider

def connect_to_astradb():
    """Connect to AstraDB and return session"""
    cloud_config = {
        'secure_connect_bundle': 'secure-connect-mercado-livre.zip'
    }


    auth_provider = PlainTextAuthProvider(
        'token', 
        'AstraCS:DZxqoocJJJrkIetdzMZjBmGy:21296745b25d62ba80cf7ce6fc97cc38864c669ea07a554032ee647aa96435e7'
    )

    cluster = Cluster(cloud=cloud_config, auth_provider=auth_provider)
    session = cluster.connect()
    
    return cluster, session

def initialize_keyspace_and_tables(session):
    """Initialize keyspace and create tables if they don't exist"""
    try:
      
        print("Verificando keyspaces disponíveis...")
        
       
        result = session.execute("SELECT keyspace_name FROM system_schema.keyspaces")
        keyspaces = [row.keyspace_name for row in result]
        print(f"Keyspaces encontrados: {keyspaces}")
        
     
        for ks in keyspaces:
            if ks not in ['system', 'system_schema', 'system_auth', 'system_distributed', 'system_traces']:
                print(f"Usando keyspace existente: {ks}")
                session.set_keyspace(ks)
                keyspace_used = ks
                break
        else:
            
            keyspace_names_to_try = ['mercadolivre', 'ecommerce', 'marketplace', 'projeto']
            keyspace_used = None
            
            for keyspace_name in keyspace_names_to_try:
                try:
                    print(f"Tentando criar keyspace: {keyspace_name}")
                    session.execute(f"""
                        CREATE KEYSPACE IF NOT EXISTS {keyspace_name}
                        WITH replication = {{'class': 'NetworkTopologyStrategy', 'datacenter1': 1}}
                    """)
                    session.set_keyspace(keyspace_name)
                    keyspace_used = keyspace_name
                    print(f"✓ Keyspace {keyspace_name} criado/conectado com sucesso!")
                    break
                except Exception as e:
                    print(f"Falha ao criar {keyspace_name}: {e}")
                    continue
            
            if not keyspace_used:
              
                print("Usando keyspace padrão do AstraDB...")
                keyspace_used = "default_keyspace"
                session.set_keyspace(keyspace_used)
    
    except Exception as e:
        print(f"Erro ao inicializar keyspace: {e}")
        print("Tentando continuar sem keyspace específico...")
    
  
    try:
        print("Criando tabelas...")
        
        session.execute("""
            CREATE TABLE IF NOT EXISTS usuarios (
                id UUID PRIMARY KEY,
                nome TEXT,
                sobrenome TEXT,
                email TEXT,
                cpf TEXT,
                senha TEXT,
                is_seller BOOLEAN
            )
        """)
        print("✓ Tabela usuarios criada")
        
        session.execute("""
            CREATE TABLE IF NOT EXISTS vendedores (
                id UUID PRIMARY KEY,
                user_id UUID,
                company_name TEXT,
                cnpj TEXT,
                rating FLOAT
            )
        """)
        print("✓ Tabela vendedores criada")
        
        session.execute("""
            CREATE TABLE IF NOT EXISTS produtos (
                id UUID PRIMARY KEY,
                nome TEXT,
                descricao TEXT,
                marca TEXT,
                valor DECIMAL,
                estoque INT,
                vendedor_id UUID
            )
        """)
        print("✓ Tabela produtos criada")
        
        session.execute("""
            CREATE TABLE IF NOT EXISTS compras (
                id UUID PRIMARY KEY,
                comprador_id UUID,
                status TEXT,
                valor_total DECIMAL,
                data_criacao TIMESTAMP
            )
        """)
        print("✓ Tabela compras criada")
        
    
        indices_criados = 0
        indices_tentativas = [
            ("CREATE INDEX IF NOT EXISTS usuario_cpf_idx ON usuarios (cpf)", "usuarios.cpf"),
            ("CREATE INDEX IF NOT EXISTS produto_nome_idx ON produtos (nome)", "produtos.nome")
        ]
        
        for query, nome in indices_tentativas:
            try:
                session.execute(query)
                indices_criados += 1
                print(f"✓ Índice criado: {nome}")
            except Exception as e:
                print(f"Aviso: Não foi possível criar índice {nome}: {e}")
        
        print(f"\n✓ Banco inicializado com sucesso! ({indices_criados}/{len(indices_tentativas)} índices criados)")
        
    except Exception as e:
        print(f"Erro ao criar tabelas: {e}")
        raise

def verify_database_structure(session):
    """Verify and display database structure"""
    print("\n--- ESTRUTURA DO BANCO ---")
    try:
   
        print(f"Keyspace atual: {session.keyspace}")
        
      
        table_check = session.execute(f"""
            SELECT table_name FROM system_schema.tables 
            WHERE keyspace_name = '{session.keyspace}'
        """)
        tables = [row.table_name for row in table_check]
        print(f"Tabelas encontradas: {tables}")
        

        for table in tables:
            if table in ['usuarios', 'produtos', 'compras', 'vendedores']:
                print(f"\nEstrutura da tabela {table}:")
                columns = session.execute(f"""
                    SELECT column_name, type FROM system_schema.columns 
                    WHERE keyspace_name = '{session.keyspace}' AND table_name = '{table}'
                """)
                for col in columns:
                    print(f"  - {col.column_name}: {col.type}")
                    
    except Exception as e:
        print(f"❌ Erro ao verificar estrutura: {e}")
