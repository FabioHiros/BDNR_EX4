
import uuid
import traceback

def inserir_produto(session):
    """Insert a new product"""
    print("\n--- INSERIR PRODUTO ---")
    try:
        cpf_vendedor = input("CPF do vendedor: ")
        
        # Buscar vendedor na tabela usuarios
        find_user = session.prepare("SELECT id, is_seller, nome FROM usuarios WHERE cpf = ? ALLOW FILTERING")
        user_rows = session.execute(find_user, [cpf_vendedor])
        user = list(user_rows)
        
        if not user:
            print("Usuário não encontrado!")
            return
        
        user_data = user[0]
        if not user_data.is_seller:
            print("Este usuário não é um vendedor!")
            print("Deseja torná-lo vendedor agora? (s/n): ", end="")
            if input().lower() != 's':
                return
            else:
                # Atualizar para vendedor na tabela usuarios
                update_user = session.prepare("UPDATE usuarios SET is_seller = ? WHERE id = ?")
                session.execute(update_user, [True, user_data.id])
                
                # Criar registro na tabela vendedores
                company_name = input("Nome da empresa: ")
                cnpj = input("CNPJ: ")
                rating = 0.0
                
                vendor_id = uuid.uuid4()
                insert_vendor = session.prepare("""
                    INSERT INTO vendedores (id, user_id, company_name, cnpj, rating)
                    VALUES (?, ?, ?, ?, ?)
                """)
                session.execute(insert_vendor, [vendor_id, user_data.id, company_name, cnpj, rating])
                print(f"✓ {user_data.nome} agora é um vendedor!")
        
        vendedor_id = user_data.id
        nome = input("Nome do produto: ")
        descricao = input("Descrição: ")
        marca = input("Marca: ")
        valor = float(input("Valor: R$ "))
        estoque = int(input("Estoque: "))
        
        product_id = uuid.uuid4()
        insert_product = session.prepare("""
            INSERT INTO produtos (id, nome, descricao, marca, valor, estoque, vendedor_id)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """)
        session.execute(insert_product, [product_id, nome, descricao, marca, valor, estoque, vendedor_id])
        
        print(f"✓ Produto '{nome}' inserido com ID: {product_id}")
        
    except Exception as e:
        print(f"❌ Erro ao inserir produto: {e}")
        traceback.print_exc()

def buscar_produto(session):
    """Search for products"""
    print("\n--- BUSCAR PRODUTO ---")
    try:
        print("1. Buscar por nome")
        print("2. Listar todos os produtos")
        
        opcao = input("Escolha uma opção: ")
        
        if opcao == '1':
            nome = input("Digite o nome do produto: ")
            find_product = session.prepare("SELECT * FROM produtos WHERE nome = ? ALLOW FILTERING")
            rows = session.execute(find_product, [nome])
        else:
            rows = session.execute("SELECT * FROM produtos")
        
        produtos = list(rows)
        
        if not produtos:
            print("Nenhum produto encontrado!")
            return
        
        print("\nProdutos encontrados:")
        print("-" * 80)
        for produto in produtos:
            # Buscar nome do vendedor
            find_vendor = session.prepare("SELECT nome FROM usuarios WHERE id = ?")
            vendedor_rows = session.execute(find_vendor, [produto.vendedor_id])
            vendedor = list(vendedor_rows)
            vendedor_nome = vendedor[0].nome if vendedor else "Desconhecido"
            
            print(f"Nome: {produto.nome}")
            print(f"Marca: {produto.marca}")
            print(f"Valor: R$ {float(produto.valor):.2f}")
            print(f"Estoque: {produto.estoque}")
            print(f"Descrição: {produto.descricao}")
            print(f"Vendedor: {vendedor_nome}")
            print("-" * 80)
            
    except Exception as e:
        print(f"❌ Erro ao buscar produto: {e}")
        traceback.print_exc()
